package com.example.temperaturecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    EditText intNum;
    Button button;
    TextView textView;
    DecimalFormat formatter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        intNum = findViewById(R.id.intNum);
        button = findViewById(R.id.button);
        textView = findViewById(R.id.textView);
        textView.setVisibility(View.GONE);
        formatter=new DecimalFormat("#0.0");
        button.setOnClickListener(view -> {
            if (intNum.getText().toString().isEmpty()) {
                Toast.makeText(MainActivity.this, "please enter all fields ", Toast.LENGTH_SHORT).show();
            }
            else{
                int noOfSounds= Integer.parseInt(intNum.getText().toString().trim());
             double calculate=(noOfSounds/3.0)+4;
             textView.setText(getString(R.string.outText)   +formatter.format(calculate));
            textView. setVisibility(View.VISIBLE);
            }
        });
    }}